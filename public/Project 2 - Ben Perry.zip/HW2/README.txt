To run my code on Mac or Linux machines simply open the terminal in the directory these files are in and run

python ProxyServer.py localhost

After starting up the server, go to http://localhost:18368/baidu.com and the baidu site should be shown.

Then, clear your browser cache and type in http://localhost:18368/baidu.com again. The baidu site should still be shown and the console should have read "Read from Cache".

On Windows, I used a program called cmder that allows the use of Linux style commands on it's command line. Simply follow the Mac/Linux steps using this terminal program.

cmder can be downloaded here: https://cmder.app