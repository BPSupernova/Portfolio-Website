To run the program, simply open up index.html in a local server. There are a few key-bindings that make the simulation more interesting. 

Press C -> Toggle the camera animation
Press D -> Toggle the view from inside or outside of the car
Press E -> Toggle the skybox on and off
Press F -> Toggle the refractions on and off
Press G -> Increase the speed of the car
Press H -> Decrease the speed of the car
Press L -> Toggle the point lighting on and off
Press M -> Toggle the car movement on and off
Press R -> Toggle reflections on and off
Press S -> Toggle shadows on and off

*SPECIAL NOTE* -> The audio that plays when the car is moving is NOT my own, it is Escape from the City, used in a Sonic game, owned by Sega. This is a personal project and is not to be launched commercially.

Enjoy messing around with the animation!