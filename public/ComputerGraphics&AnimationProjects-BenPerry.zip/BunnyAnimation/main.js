/* For extra credit I added sound when the car is moving and also programmed two simple functions to speed up and slow down the car */

let canvas, gl, program;

// Car & Camera animation data
let cameraAnimating, carAnimating = false;
let animationStartTime = null;
let cameraAngle = 0;
let carSpeed = 2000;
let carAngle = 0;
let cameraHeight = 5;
let carViewEnabled = false;
let pausedTime = 0; // The time the animation is stopped at
let accumulatedPauseTime = 0; // time passed while camera animation is paused
let camAnimPaused, carAnimPaused = false;

// Boolean values for toggle functions and activating features
let lightSwitch = true;
let showShadows = true;
let skyboxEnabled = true;
let enableReflections = true;
let enableRefractions = true;

// Buffers to store model data in
let vertexBuffer; // Vertex data
let normalBuffer; // Normals data
let textureBuffer; // Texture data
let colorBuffer; // Color data

// Matrices
let modelMatrix, cameraMatrix, projMatrix;
let modelMatrixLoc, cameraLoc, projLoc, shadowLoc;
let defaultCameraMatrix = lookAt(vec3(0.0, 5.0, 5.0), vec3(0.0, 1.0, 0.0), vec3(0.0, 1.0, 0.0));

// Heirarchy Data
let stopSignNode, lampNode, carNode, streetNode, bunnyNode, cameraNode;
let sceneTree;

// Get the stop sign
let stopSign = new Model(
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/stopsign.obj",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/stopsign.mtl");

    let stopSignTexture;

// Get the lamp
let lamp = new Model(
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/lamp.obj",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/lamp.mtl");

    var lightAmbient = vec4(0.4, 0.4, 0.4, 1.0); 
    var lightDiffuse = vec4(1.0, 0.0, 1.0, 1.0); 
    var lightSpecular = vec4(1.0, 1.0, 1.0, 1.0); 
    var shininess = 10.0; 

    var lightPosition = vec4(lamp.position[0], lamp.position[1] + 6, lamp.position[2], 1.0);

// Get the car
let car = new Model(
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/car.obj",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/car.mtl");

// Get the street
let street = new Model(
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/street.obj",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/street.mtl");

// Get the bunny (you will not need this one until Part II)
let bunny = new Model(
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/bunny.obj",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/bunny.mtl");

// Create nodes
stopSignNode = new Node(stopSign, mat4()); 
lampNode = new Node(lamp, mat4());
carNode = new Node(car, mat4());
streetNode = new Node(street, mat4());
bunnyNode = new Node(bunny, mat4());
cameraNode = new Node(null, mat4());

// Bunny becomes a child of the car
carNode.children.push(bunnyNode);

// Create the scene tree with the car as the root
sceneTree = new Tree(carNode);

// Heirarchy stack
let stack = [];

function Tree(root) {
    this.root = root;
}

function Node(model, modelMatrix) {
    this.model = model;
    this.modelMatrix = modelMatrix;
    this.children = [];
}

var models = [stopSign, lamp, car, street, bunny];

// Skybox Stuff
let cubeMap;

let skyboxPoints = [];
let skyboxTextures = [];

let skyboxImagesLoaded = 0;
let skyboxImageBitmaps = [];  // Stores ImageBitmaps
let skyboxFaces = [ 
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_posx.png",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_negx.png",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_posy.png",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_negy.png",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_posz.png",
    "https://web.cs.wpi.edu/~jmcuneo/cs4731/project3/skybox_negz.png"
];

function main() {
    const KEY_HANDLERS = {
        KeyC: () => toggleCameraAnimation(),
        KeyD: () => toggleCarCameraView(),
        KeyE: () => toggleSkybox(),
        KeyF: () => toggleRefractions(),
        KeyG: () => increaseCarSpeed(),
        KeyH: () => decreaseCarSpeed(),
        KeyL: () => togglePointLighting(),
        KeyM: () => toggleCarMovement(),
        KeyR: () => toggleReflections(),
        KeyS: () => toggleShadows(),
    };

    // Retrieve <canvas> element
    canvas = document.getElementById('webgl');
    audioPlayer = document.getElementById('audioPlayer');

    // Get the rendering context for WebGL
    gl = WebGLUtils.setupWebGL(canvas, undefined);

    // Check that the return value is not null.
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return;
    }

    // Set viewport
    gl.viewport(0, 0, canvas.width, canvas.height);

    // Enable depth testing
    gl.enable(gl.DEPTH_TEST);

    // Enable back-face culling
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    // Set clear color
    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    // Initialize shaders
    program = initShaders(gl, "vshader", "fshader"); 
    if (!program) {
        console.error("Failed to initialize shaders.");
        return;
    }
    gl.useProgram(program);

    fillCube();

    // Set up matrices for vertex shader
    modelMatrix = mat4();
    modelMatrixLoc = gl.getUniformLocation(program, "modelMatrix");
    gl.uniformMatrix4fv(modelMatrixLoc, false, flatten(mat4()));

    cameraMatrix = lookAt(vec3(0.0, 5.0, 5.0), vec3(0.0, 1.0, 0.0), vec3(0.0, 1.0, 0.0));
    cameraLoc = gl.getUniformLocation(program, 'cameraMatrix');
    gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));

    projMatrix = perspective(90.0, canvas.height / (canvas.width / 2), 0.1, 500);
    projLoc = gl.getUniformLocation(program, 'projMatrix');
    gl.uniformMatrix4fv(projLoc, false, flatten(projMatrix));

    shadowMatrixLoc = gl.getUniformLocation(program, "shadowMatrix");

    // Set up boolean values for the shaders
    gl.uniform1i(gl.getUniformLocation(program, "lightSwitch"), lightSwitch);
    gl.uniform1f(gl.getUniformLocation(program, "shininess"), shininess);
    gl.uniform1i(gl.getUniformLocation(program, "enableShadows"), showShadows);
    gl.uniform1i(gl.getUniformLocation(program, "enableReflections"), 0);
    gl.uniform1i(gl.getUniformLocation(program, "enableRefractions"), 0);

    configureDefaultTexture();
    configureDefaultCubeMap();

    skyboxFaces.forEach((src, index) => {
        let image = new Image();
        image.crossOrigin = "anonymous";
        image.src = src;
    
        image.onload = async () => {  // Runs when an image is fully loaded
            try {
                let bitmap = await createImageBitmap(image);  // Convert the image to ImageBitmap
                skyboxImageBitmaps[index] = bitmap;
                skyboxImagesLoaded++;
    
                console.log(`Skybox face ${index} loaded`);
    
                if (skyboxImagesLoaded === skyboxFaces.length) {
                    configureSkybox(skyboxImageBitmaps); // Configures the skybox once all images are loaded
                    console.log("All skybox images loaded and configured.");
                }
            } catch (error) {
                console.error("Error creating ImageBitmap:", error);
            }
        };
    
        image.onerror = () => {
            console.error(`Failed to load skybox texture: ${image.src}`);
        };
    });

    initializeBuffers();
    loadSceneData();

    document.addEventListener('keydown', (evt) => {
        evt.preventDefault();
        const transformationHander = KEY_HANDLERS[evt.code];

        if (transformationHander) {
            transformationHander();
            return;
        }
        
        console.log('Pressed a key without a handler.')
    });
}

/**
 * Computes the shadow polygon generation matrix to be used elsewhere
 */
function computeShadowMatrix() {
    let shadowMatrix = mat4();
    shadowMatrix[3][3] = 0;
    shadowMatrix[3][1] = -1 / lightPosition[1];
    return shadowMatrix;
}

/**
 * Turns lighting on and off
 */
function togglePointLighting() {
    console.log('Lighting toggled');
    lightSwitch = !lightSwitch;
    gl.uniform1i(gl.getUniformLocation(program, "lightSwitch"), lightSwitch);
}

/**
 * Animates the camera moving 360 degrees around the scene and bobs a bit as well
 */
function toggleCameraAnimation() {
    console.log('Camera Toggled');
    cameraAnimating = !cameraAnimating;
    if (cameraAnimating) { // Resume animation
        if (camAnimPaused) {
            accumulatedPauseTime += performance.now() - pausedTime;
            camAnimPaused = false;
        } else { // Start animation
            animationStartTime = performance.now();
            accumulatedPauseTime = 0;
        }
    }

    else { // Stop Animating
        cameraAnimating = false;
        camAnimPaused = true;
        pausedTime = performance.now();
    }
}

/**
 * Attachs an detachs the camera view to the front of the car
 */
function toggleCarCameraView(){
    console.log('Car View Toggled');
    carViewEnabled = !carViewEnabled;
    if (carViewEnabled) {
        cameraMatrix = mult(mat4(), translate(-2.7, -1.3, 0.8));
        gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));
        carNode.children.push(cameraNode);
    } else {
        carNode.children.pop();
        cameraMatrix = defaultCameraMatrix;
        gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));
    }
}

/**
 * Animates the car in motion or pauses the car's movement while in motion
 */
function toggleCarMovement() {
    carAnimating = !carAnimating;
    if (carAnimating) { // Resume animation
        audioPlayer.play();
        if (carAnimPaused) {
            accumulatedPauseTime += performance.now() - pausedTime;
            carAnimPaused = false;
        } else { // Start animation
            animationStartTime = performance.now();
            accumulatedPauseTime = 0;
        }
    }

    else { // Stop Animating
        audioPlayer.pause();
        carAnimating = false;
        carAnimPaused = true;
        pausedTime = performance.now();
    }
}

/**
 * Toggles shadows on and off
 */
function toggleShadows() {
    showShadows = ! showShadows;
}

/**
 * Toggles the skybox in the scene on and off
 */
function toggleSkybox() {
    console.log('Toggling skybox');
    skyboxEnabled = !skyboxEnabled;
}

/**
 * Toggles reflections on the car model on and off
 */
function toggleReflections() {
    enableReflections = !enableReflections;
}

/**
 * Toggles refractions on the bunny model on and off
 */
function toggleRefractions() {
    enableRefractions = !enableRefractions;
}

/**
 * A function that increases the animation speed of the car while it's moving
 * Resets the model's position back by the stopSign
 */
function increaseCarSpeed() {
    if (carAnimating) carSpeed /= 2;
}

/**
 * A function that decreases the animation speed of the car while it's moving
 * Resets the model's position back by the stopSign 
 */
function decreaseCarSpeed() {
    if (carAnimating) carSpeed *= 2;
}