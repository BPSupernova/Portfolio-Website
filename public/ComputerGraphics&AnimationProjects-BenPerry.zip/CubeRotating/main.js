let gl;
let canvas;
let program;

let baseModelMatrix, controlModelMatrix, cameraMatrix, projMatrix;
let modelMatrixLoc, cameraLoc, projLoc;

// Data arrays to house data for the moving cube
let basePointsArray = []; 
let baseNormalsArray = []; 
let baseColorsArray = []; 

// Data arrays to house data for the control point cubes
let controlPointsArray = [];
let controlNormalsArray = [];
let controlColorsArray = [];

let vNormal, vPosition, vColor;
let baseVertexBuffer, baseNormalBuffer, baseColorBuffer;
let controlVertexBuffer, controlNormalBuffer, controlColorBuffer;

let currentSpline = null;
let splineType = 'catmull';

let animationRunning = false;
let animationStartTime = 0;
let animationCycleCount = 0;

function main() {
    canvas = document.getElementById('webgl');
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) {
        console.log('Failed to get WebGL context');
        return;
    }

    program = initShaders(gl, "vshader", "fshader");
    gl.useProgram(program);

    gl.viewport(0, 0, canvas.width, canvas.height);

    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    baseModelMatrix = mat4();
    controlModelMatrix = mat4();
    modelMatrixLoc = gl.getUniformLocation(program, "modelMatrix");

    cameraMatrix = lookAt(vec3(0.0, 2.0, 10.0, 0.0), vec3(0.0, 1.0, 0.0), vec3(0.0, 1.0, 0.0));
    cameraLoc = gl.getUniformLocation(program, 'cameraMatrix');
    gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));

    projMatrix = perspective(90.0, canvas.width / canvas.height, 0.1, 500);
    projLoc = gl.getUniformLocation(program, 'projMatrix');
    gl.uniformMatrix4fv(projLoc, false, flatten(projMatrix));

    let lightPosition = vec4(1.0, 1.0, 3.0, 1.0);
    let lightAmbient = vec4(0.2, 0.2, 0.2, 1.0);
    let lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
    let lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);

    let materialAmbient = vec4(1.0, 0.0, 1.0, 1.0);
    let materialDiffuse = vec4(0.0, 1.0, 0.0, 1.0);
    let materialSpecular = vec4(1.0, 1.0, 1.0, 1.0);
    let materialShininess = 20.0;

    let ambientProduct = mult(lightAmbient, materialAmbient);
    let diffuseProduct = mult(lightDiffuse, materialDiffuse);
    let specularProduct = mult(lightSpecular, materialSpecular);

    gl.uniform4fv(gl.getUniformLocation(program, "ambientProduct"), flatten(ambientProduct));
    gl.uniform4fv(gl.getUniformLocation(program, "diffuseProduct"), flatten(diffuseProduct));
    gl.uniform4fv(gl.getUniformLocation(program, "specularProduct"), flatten(specularProduct));
    gl.uniform4fv(gl.getUniformLocation(program, "lightPosition"), flatten(lightPosition));
    gl.uniform1f(gl.getUniformLocation(program, "shininess"), materialShininess);

    generateCube();
    initializeBuffers();

    gl.bindBuffer(gl.ARRAY_BUFFER, baseVertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(basePointsArray), gl.STATIC_DRAW);
    vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, baseNormalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(baseNormalsArray), gl.STATIC_DRAW);
    vNormal = gl.getAttribLocation(program, "vNormal");
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vNormal);

    gl.bindBuffer(gl.ARRAY_BUFFER, baseColorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(baseColorsArray), gl.STATIC_DRAW);
    vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    requestAnimationFrame(render);

    /* Event Handlers */
    let fileInputElement = document.getElementById("files");
    fileInputElement.addEventListener("change", function (evt) {
        createNewSpline(evt);
    });
}

/**
 * Initializes the buffers for both the animating cube (base cube) and the control point cubes
 */
function initializeBuffers() {
    baseVertexBuffer = gl.createBuffer();
    baseNormalBuffer = gl.createBuffer();
    baseColorBuffer = gl.createBuffer();

    controlVertexBuffer = gl.createBuffer();
    controlNormalBuffer = gl.createBuffer();
    controlColorBuffer = gl.createBuffer();
}

/**
 * Generates data for a large, multicolored cube (The object to be animated)
 * The generated data (vertex, normal, and color data) is then pushed into arrays for storage
 */
function generateCube() {
    let tempPoints = [];
    let tempNormals = [];
    let tempColors = [];

    function addFace(v0, v1, v2, v3, normal, color) {
        tempPoints.push(v0, v1, v2, v0, v2, v3);
        tempNormals.push(normal, normal, normal, normal, normal, normal);
        tempColors.push(color, color, color, color, color, color);
    }

    let vertices = [
        vec4(-1, -1, 1, 1), vec4(1, -1, 1, 1), vec4(1, 1, 1, 1), vec4(-1, 1, 1, 1),
        vec4(-1, -1, -1, 1), vec4(1, -1, -1, 1), vec4(1, 1, -1, 1), vec4(-1, 1, -1, 1)
    ];

    let faceColors = [
        vec4(1, 0, 0, 1),
        vec4(0, 1, 0, 1),
        vec4(0, 0, 1, 1),
        vec4(1, 1, 0, 1),
        vec4(1, 0, 1, 1),
        vec4(0, 1, 1, 1)
    ];

    addFace(vertices[0], vertices[1], vertices[2], vertices[3], vec3(0, 0, 1), faceColors[0]);
    addFace(vertices[5], vertices[4], vertices[7], vertices[6], vec3(0, 0, -1), faceColors[1]);
    addFace(vertices[3], vertices[2], vertices[6], vertices[7], vec3(0, 1, 0), faceColors[2]);
    addFace(vertices[4], vertices[5], vertices[1], vertices[0], vec3(0, -1, 0), faceColors[3]);
    addFace(vertices[1], vertices[5], vertices[6], vertices[2], vec3(1, 0, 0), faceColors[4]);
    addFace(vertices[4], vertices[0], vertices[3], vertices[7], vec3(-1, 0, 0), faceColors[5]);

    basePointsArray.push(...tempPoints);
    baseNormalsArray.push(...tempNormals);
    baseColorsArray.push(...tempColors);
}

/**
 * Pushes the vertex, normal, and color data of a cube to be created
 * at the center of a control point for visual aid during the animation
 * @param {*} point A 3D control point
 */
function generateControlPointCube(point) {
    let tempPoints = [];
    let tempNormals = [];
    let tempColors = [];

    function addFace(v0, v1, v2, v3, normal, color) {
        tempPoints.push(v0, v1, v2, v0, v2, v3);
        tempNormals.push(normal, normal, normal, normal, normal, normal);
        tempColors.push(color, color, color, color, color, color);
    }

    let vertices = [
        vec4(point.x - 0.5, point.y - 0.5, point.z + 0.5, 1), vec4(point.x + 0.5, point.y - 0.5, point.z + 0.5, 1),
        vec4(point.x + 0.5, point.y + 0.5, point.z + 0.5, 1), vec4(point.x - 0.5, point.y + 0.5, point.z + 0.5, 1),
        vec4(point.x - 0.5, point.y - 0.5, point.z - 0.5, 1), vec4(point.x + 0.5, point.y - 0.5, point.z - 0.5, 1),
        vec4(point.x + 0.5, point.y + 0.5, point.z - 0.5, 1), vec4(point.x - 0.5, point.y + 0.5, point.z - 0.5, 1)
    ];

    let faceColors = [
        vec4(0.3, 1, 0.3, 1),
        vec4(0.3, 1, 0.3, 1),
        vec4(0.3, 1, 0.3, 1),
        vec4(0.3, 1, 0.3, 1),
        vec4(0.3, 1, 0.3, 1),
        vec4(0.3, 1, 0.3, 1)
    ];

    addFace(vertices[0], vertices[1], vertices[2], vertices[3], vec3(0, 0, 1), faceColors[0]);
    addFace(vertices[5], vertices[4], vertices[7], vertices[6], vec3(0, 0, -1), faceColors[1]);
    addFace(vertices[3], vertices[2], vertices[6], vertices[7], vec3(0, 1, 0), faceColors[2]);
    addFace(vertices[4], vertices[5], vertices[1], vertices[0], vec3(0, -1, 0), faceColors[3]);
    addFace(vertices[1], vertices[5], vertices[6], vertices[2], vec3(1, 0, 0), faceColors[4]);
    addFace(vertices[4], vertices[0], vertices[3], vertices[7], vec3(-1, 0, 0), faceColors[5]);

    controlPointsArray.push(...tempPoints);
    controlNormalsArray.push(...tempNormals);
    controlColorsArray.push(...tempColors);
}

/**
 * A function that repositions the camera when a spline is active by
 * taking the midpoint of the control points in 2D (x, y) and customizing the z distance
 */
function repositionCamera() {
    if (!currentSpline || currentSpline.pointsData.length === 0) {
        console.error("No spline data available.");
        return;
    }

    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;
    let minZ = Infinity, maxZ = -Infinity;
    let count = 0;

    currentSpline.pointsData.forEach(splineData => {
        splineData.positions.forEach(pos => {
            minX = Math.min(minX, pos.x);
            maxX = Math.max(maxX, pos.x);
            minY = Math.min(minY, pos.y);
            maxY = Math.max(maxY, pos.y);
            minZ = Math.min(minZ, pos.z);
            maxZ = Math.max(maxZ, pos.z);
            count++;
        });
    });

    if (count === 0) {
        console.error("No control points found.");
        return;
    }

    const midpoint = vec3(
        (minX + maxX) / 2,
        (minY + maxY) / 2,
        (minZ + maxZ) / 2
    );

    const sizeX = maxX - minX;
    const sizeY = maxY - minY;
    const sizeZ = maxZ - minZ;
    const maxSize = Math.max(sizeX, sizeY, sizeZ);
    const cameraDistance = Math.max(maxSize * 2.5, 5);

    const cameraPosition = vec3(
        midpoint[0],
        midpoint[1],
        10
    );

    const cameraTarget = midpoint;
    const upVector = vec3(0, 1, 0);

    cameraMatrix = lookAt(cameraPosition, cameraTarget, upVector);
    gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));
}

/**
 * Updates the buffers with new data to redraw the scene with
 */
function update() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // Render moving cube
    gl.uniformMatrix4fv(modelMatrixLoc, false, flatten(baseModelMatrix));
    gl.bindBuffer(gl.ARRAY_BUFFER, baseVertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(basePointsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, baseNormalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(baseNormalsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vNormal);

    gl.bindBuffer(gl.ARRAY_BUFFER, baseColorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(baseColorsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    gl.drawArrays(gl.TRIANGLES, 0, basePointsArray.length);

    // Render control point cubes
    gl.uniformMatrix4fv(modelMatrixLoc, false, flatten(controlModelMatrix));
    gl.bindBuffer(gl.ARRAY_BUFFER, controlVertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(controlPointsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, controlNormalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(controlNormalsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vNormal);

    gl.bindBuffer(gl.ARRAY_BUFFER, controlColorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(controlColorsArray), gl.STATIC_DRAW);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    gl.drawArrays(gl.TRIANGLES, 0, controlPointsArray.length);
}

let startTime = Date.now();

/**
 * This function runs the render loop that animates a large cube following a cutmullRom spline,
 * then a uniformBSpline, rotating where necessary using slerping, and then stopping
 */
function render() {
    if (!animationRunning) return;

    const currentTime = (Date.now() - animationStartTime) / 1000;
    baseModelMatrix = mat4();

    if (currentSpline) {
        const splineData = currentSpline.pointsData[0];
        const positions = splineData.positions;
        const rotations = splineData.rotations;
        const numPoints = positions.length;
        const totalAnimTime = currentSpline.animTime * 2; // 2 cycles total

        // Stop after completing both cycles
        if (currentTime >= totalAnimTime) {
            animationRunning = false;
            return;
        }

        // Determine active cycle
        const cycle = Math.floor(currentTime / currentSpline.animTime);
        const cycleProgress = (currentTime % currentSpline.animTime) / currentSpline.animTime;
        const currentSplineType = (cycle === 0) ? 'catmull' : 'uniformB';

        // Calculate segment position
        const t = cycleProgress * (numPoints - 3);
        const segment = Math.floor(t);
        const T = t - segment;

        // Control point indices
        const p0 = positions[segment];
        const p1 = positions[segment + 1];
        const p2 = positions[segment + 2];
        const p3 = positions[segment + 3];

        // Position interpolation
        let interpolatedPosition;
        if (currentSplineType === 'catmull') {
            interpolatedPosition = currentSpline.catmullSpline(p0, p1, p2, p3, T);
        } else {
            interpolatedPosition = currentSpline.uniformBSpline(p0, p1, p2, p3, T);
        }

        // Rotation interpolation
        const q0 = euler2Quaternion(
            rotations[segment + 1].xRot, 
            rotations[segment + 1].yRot, 
            rotations[segment + 1].zRot
        );
        const q1 = euler2Quaternion(
            rotations[segment + 2].xRot, 
            rotations[segment + 2].yRot, 
            rotations[segment + 2].zRot
        );
        const interpolatedQuaternion = slerp(q0, q1, T);
        const eulerAngles = quaternion2Euler(interpolatedQuaternion);

        // Apply transformations
        baseModelMatrix = mult(baseModelMatrix, translate(
            interpolatedPosition.x, 
            interpolatedPosition.y, 
            interpolatedPosition.z
        ));
        baseModelMatrix = mult(baseModelMatrix, rotateX(degrees(eulerAngles[0])));
        baseModelMatrix = mult(baseModelMatrix, rotateY(degrees(eulerAngles[1])));
        baseModelMatrix = mult(baseModelMatrix, rotateZ(degrees(eulerAngles[2])));
    }

    update();
    
    if (animationRunning) {
        requestAnimationFrame(render);
    }
}

/**
 * Renders the cubes centered at the control points of the input spline
 * @param {*} spline A spline object
 */
function renderControlPoints(spline) {
    controlPointsArray = [];
    controlNormalsArray = [];
    controlColorsArray = [];

    spline.pointsData.forEach(splineData => {
        splineData.positions.forEach(position => {
            generateControlPointCube(position);
        });
    });

    update();
}

/**
 * Toggles between the type of spline the cube follows and uses for interpolation
 * Toggles between the catmullRom and uniformBSpline algorithms
 */
function toggleSplineType() {
    if (splineType == 'catmull') splineType = 'uniformB';
    else splineType = 'catmull';
}

/**
 * Resets the cube animation 
 */
function resetAnimation() {
    animationRunning = true;
    animationStartTime = Date.now();
    requestAnimationFrame(render);
}