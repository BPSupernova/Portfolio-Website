'use strict';

let gl;
let particles = [];
let program;
let vBuffer;
const numParticles = 51;
const radius = 0.03;
const canvasSize = 1.0;

const maxSpeed = 0.5;
const maxForce = 0.005;
const sensingRadius = 0.2;
const separationDistance = 0.5;

const specieColors = {
    red: [1.0, 0.0, 0.0],
    green: [0.0, 1.0, 0.0], 
    blue: [0.0, 0.0, 1.0],
};

const interactionRules = {
    redRule: new Rule("blue", "green"),
    blueRule: new Rule("green", "red"),
    greenRule: new Rule("red", "blue"),
};

const behaviorWeights = {
    alignWeight: 0.5, 
    cohereWeight: 0.5,
    separateWeight: 1.0,
    attractWeight: 0.7,
    evadeWeight: 0.9,
}

const envObstacle = {
    position: vec2(0, 0),
    size: 0.1,
    ffStrength: 0.005, // Strength of the obstacle's forcefield
    shape: 'diamond', // Options are 'diamond' or 'circle'
}

// Particle class to manage position and velocity
class Particle {
    constructor(species, behavior) {
        this.species = species;
        this.behavior = behavior;
        this.position = vec2(Math.random() * 2 - 1, Math.random() * 2 - 1);
        this.velocity = vec2((Math.random() - 0.5) * maxSpeed, (Math.random() - 0.5) * maxSpeed);
        this.accel = vec2(0, 0);
        this.color = specieColors[species];
    }

    // Update position based on velocity
    update(dt) {
        this.position = add(this.position, scale(dt, this.velocity));
        this.velocity = add(this.velocity, this.accel);

        if (length(this.velocity) > maxSpeed) {
            this.velocity = normalize(this.velocity);
            this.velocity = scale(maxSpeed, this.velocity);
        }
        this.accel = scale(0, this.accel);
    }

    applyForce(force) {
        this.accel = add(this.accel, force);
    }

    /**
     *  Handles collisions between this particle and the four walls
     */
    handleWallCollisions() {
        if (this.position[0] > (1 - radius) || this.position[0] < (-1 + radius)) {
            this.velocity[0] *= -1;
        }
        if (this.position[1] > (1 - radius) || this.position[1] < (-1 + radius)) {
            this.velocity[1] *= -1;
        } 
    }

    /**
     * Handles collisions between this particle and another particle p.
     * @param p The other particle used for collision detection.
     */
    handleParticleCollisions(p) {
        const dx = p.position[0] - this.position[0];
        const dy = p.position[1] - this.position[1];
        const distanceSquared = dx * dx + dy * dy;
        const minDistance = radius * 2;
        const minDistanceSquared = minDistance * minDistance;
    
        if (distanceSquared < minDistanceSquared && distanceSquared > 0) {
            const distance = Math.sqrt(distanceSquared);
            
            let tempSpecies = p.species;
            p.species = this.species;
            p.color = specieColors[p.species];

            this.species = tempSpecies;
            this.color = specieColors[this.species];

            const nx = dx / distance;
            const ny = dy / distance;

            const dvx = p.velocity[0] - this.velocity[0];
            const dvy = p.velocity[1] - this.velocity[1];
            
            const velocityAlongNormal = dvx * nx + dvy * ny;
            
            if (velocityAlongNormal > 0) return;
            
            const impulse = 2 * velocityAlongNormal / (1 + 1);
            
            this.velocity[0] += impulse * nx;
            this.velocity[1] += impulse * ny;
            p.velocity[0] -= impulse * nx;
            p.velocity[1] -= impulse * ny;
            
            const correction = (minDistance - distance) / 2;
            this.position[0] -= nx * correction;
            this.position[1] -= ny * correction;
            p.position[0] += nx * correction;
            p.position[1] += ny * correction;
        }
    }

    align(particles) {
        let steering = vec2(0, 0);
        let total = 0;

        for (let other of particles) {
            const d = distance(this.position, other.position);
            if (d > 0 && d < sensingRadius) {
                steering = add(steering, other.velocity);
                total++;
            }
        }

        if (total > 0) {
            steering = scale(1 / total, steering);
            steering = normalize(steering);
            steering = scale(maxSpeed, steering);
            steering = subtract(steering, this.velocity);

            if (length(steering) > maxForce) {
                steering = normalize(steering);
                steering = scale(maxForce, steering);
            }
        }

        return steering;
    }

    cohere(particles) {
        let steering = vec2(0, 0);
        let total = 0;

        for (let other of particles) {
            let d = distance(this.position, other.position);
            if (d > 0 && d < sensingRadius) {
                steering = add(steering, other.position);
                total++;
            }
        }

        if (total > 0) {
            steering = scale(1 / total, steering);
            return this.seek(steering);
        }

        return steering;
    }

    separate(particles) {
        let steering = vec2(0, 0);
        let total = 0;

        for (let other of particles) {
            const d = distance(this.position, other.position);
            if (d > 0 && d < sensingRadius) {
                let diff = subtract(this.position, other.position);
                diff = scale(1 / (d * d), diff);
                steering = add(steering, diff);
                total++;
            }
        }

        if (total > 0) {
            steering = scale(1 / total, steering);
            if (length(steering) > 0) {
                steering = normalize(steering);
                steering = scale(maxSpeed, steering);
                steering = subtract(steering, this.velocity);

                if (length(steering) > maxForce) {
                    steering = normalize(steering);
                    steering = scale(maxForce, steering);
                }
            }
        }

        return steering;
    }

    attract(particles) {
        let steering = vec2(0, 0);
        let total = 0;

        for (let other of particles) {
            if (other.species === this.behavior.attract) {
                const d = distance(this.position, other.position);
                if (d > 0 && d < sensingRadius * 1.5) {
                    steering = add(steering, other.position);
                    total++;
                }
            }
        }

        if (total > 0) {
            steering = scale(1 / total, steering);
            return this.seek(steering);
        }

        return steering;
    }

    evade(particles) {
        let steering = vec2(0, 0);
        let total = 0;

        for (let other of particles) {
            if (other.species === this.behavior.evade) {
                const d = distance(this.position, other.position);
                if (d > 0 && d < sensingRadius * 1.2) {
                    steering = add(steering, other.position);
                    total++;
                }
            }
        }

        if (total > 0) {
            steering = scale(1 / total, steering);
            return this.flee(steering);
        }

        return steering;
    }

    seek(target) {
        let desired = subtract(target, this.position);
        if (length(desired) > 0) {
            desired = normalize(desired);
            desired = scale(maxSpeed, desired);
            let steer = subtract(desired, this.velocity);

            if(length(steer) > maxForce) {
                steer = normalize(steer);
                steer = scale(maxForce, steer);
            }
            return steer;
        }

        return vec2(0, 0);
    }

    flee(target) {
        let horror = subtract(this.position, target);
        if(length(horror) > 0) {
            horror = normalize(horror);
            horror = scale(maxSpeed, horror);
            let steer = subtract(horror, this.velocity);
            
            if (length(steer) > maxForce) {
                steer = normalize(steer);
                steer = scale(maxForce, steer);
            }

            return steer;
        }

        return vec2(0, 0);
    }

    flock(particles) {
        const sameSpecies = particles.filter(p => p !== this && p.species === this.species); // All particles same species
        const otherSpecies = particles.filter(p => p !== this && p.species !== this.species); // All particles different species
    
        let alignment = this.align(sameSpecies);
        let cohesion = this.cohere(sameSpecies);
        let separation = this.separate(sameSpecies);

        let attraction = this.attract(otherSpecies);
        let evasion = this.evade(otherSpecies);

        let avoidance = this.avoidObstacles();

        alignment = scale(behaviorWeights.alignWeight, alignment);
        cohesion = scale(behaviorWeights.cohereWeight, cohesion);
        separation = scale(behaviorWeights.separateWeight, separation);
        attraction = scale(behaviorWeights.attractWeight, attraction);
        evasion = scale(behaviorWeights.evadeWeight, evasion);

        this.applyForce(alignment);
        this.applyForce(cohesion);
        this.applyForce(separation);
        this.applyForce(attraction);
        this.applyForce(evasion);
        this.applyForce(avoidance);
    }

    avoidObstacles() {
        let avoidanceForce = vec2(0, 0);
        if (envObstacle.shape === 'diamond') {
            const d = diamondDistance(this.position, envObstacle.position, envObstacle.size);

            if (d < 1.0) {
                let pushDir = subtract(this.position, envObstacle.position);
                if (length(pushDir) > 0) {
                    pushDir = normalize(pushDir);
                    const strength = envObstacle.ffStrength * (1.0 - d);
                    avoidanceForce = scale(strength, pushDir);
                }
            }
        } else {
            const d = distance(this.position, envObstacle.position);
            if (d < envObstacle.size) {
                let pushDir = subtract(this.position, envObstacle.position);
                if (length(pushDir) > 0) {
                    pushDir = normalize(pushDir);
                    const strength = envObstacle.ffStrength * (1.0 - d / envObstacle.size);
                    avoidanceForce = scale(strength, pushDir);
                }
            }
        }

        return avoidanceForce;
    }

    // Draw particle as a point
    render() {
        gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, flatten(this.position));
        const uColorLocation = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColorLocation, this.color);
        gl.drawArrays(gl.POINTS, 0, 1);
    }
}

// Initialize WebGL and simulation
function main() {
    const canvas = document.getElementById("webgl");
    gl = WebGLUtils.setupWebGL(canvas, null);
    if (!gl) { alert("WebGL isn't available"); return; }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    program = initShaders(gl, "vshader", "fshader");
    gl.useProgram(program);

    // Allocate buffer for one particle position
    vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vec2(0, 0)), gl.DYNAMIC_DRAW);

    const vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    initParticles();
    render();
}

// Collision detection and response between particles
function handleCollisionsBetweenParticles() {
    for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
            const pi = particles[i];
            const pj = particles[j];
            pi.handleParticleCollisions(pj);
        }
    }
}

function initParticles() {
    const specieTypes = ["red", "green", "blue"];
    for (let i = 0; i < numParticles; i++) {
        const species = specieTypes[i % 3];
        let behavior; 
        if (i % 3 == 0) behavior = interactionRules.redRule;
        else if (i % 3 == 1) behavior = interactionRules.greenRule;
        else behavior = interactionRules.blueRule; 
        particles.push(new Particle(species, behavior));
    }
}

function drawDiamond(position, size, color) {
    const vertices = [
        position[0], position[1] + size, 
        position[0] + size, position[1], 
        position[0], position[1] - size, 
        position[0] - size, position[1], 
    ];

    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    const uColorLocation = gl.getUniformLocation(program, "uColor");
    gl.uniform3fv(uColorLocation, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function drawCircle(position, size, color) {
    const segments = 32;
    const vertices = [];
    
    for (let i = 0; i <= segments; i++) {
        const angle = (i / segments) * Math.PI * 2;
        vertices.push(
            position[0] + Math.cos(angle) * size,
            position[1] + Math.sin(angle) * size
        );
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    const uColorLocation = gl.getUniformLocation(program, "uColor");
    gl.uniform3fv(uColorLocation, color);
    gl.drawArrays(gl.LINE_LOOP, 0, segments + 1);
}

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    const dt = 0.01;

    if (envObstacle.shape === "diamond") {
        drawDiamond(envObstacle.position, envObstacle.size, [0.5, 0.5, 0.4]);
    } else {
        drawCircle(envObstacle.position, envObstacle.size, [0.8, 0.2, 0.4]);
    }

    for (let p of particles) {
        p.flock(particles);
    }

    for (let p of particles) {
        p.update(dt);
        p.handleWallCollisions();
        p.render();
    }

    handleCollisionsBetweenParticles();
    requestAnimationFrame(render);
}

function distance(a, b) {
    const dx = a[0] - b[0];
    const dy = a[1] - b[1];
    return Math.sqrt(dx * dx + dy * dy);
}

function diamondDistance(point, center, size) {
    const dx = point[0] - center[0];
    const dy = point[1] - center[1];
    return (dx + dy) / size;
}