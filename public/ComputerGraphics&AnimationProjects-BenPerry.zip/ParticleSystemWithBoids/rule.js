class Rule {
    constructor(likedSpecies, dislikedSpecies) {
        this.attract = likedSpecies;
        this.evade = dislikedSpecies;
    }
}