To run the program, simply open up index.html in a local server. There are a few key-bindings that make the animation more interesting. 

Clicking the arrow keys -> Moves the point lighting

Press A -> Starts / stops the sphere from animating
Press G -> Increases the number of subdivisions on the spline the sphere animates on
Press H -> Decreases the number of subdivisions on the spline the sphere animates on
Press J -> Decreases the number of subdivisions on the sphere itself
Press K -> Increases the number of subdivisions on the sphere itself
Press L -> Toggle the shading on the sphere on and off
Press M -> Toggle the mode between wired mode and lit mode

Enjoy!