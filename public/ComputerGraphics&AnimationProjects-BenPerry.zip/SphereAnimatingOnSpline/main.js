/* For Part 4 aka the Extra stuff I implemented the ability to move the point light with the array keys 
- functionality present at the bottom of this file */

let canvas;
let gl;
let program;

var mode; // Wireframe vs filled lit mode

var numTimesToSubdivide = 4; // Subdivisions for the sphere
var lineSubdivisions = 6; // Subdivisions for the path

var index = 0;

var pointsArray = []; // Stores the vertice data for the sphere in an array for later use
var normalsArray = []; // Stores normal Data for the sphere in an array for later use
var flatShadingArray = []; // Stores flat Shading data in array for later use

var pathPointsArray = []; // Stores the vertice data for path in array for later use

// Vertices for unit cube centered at the origin
// Vertices for the front face
var ucva = vec4(-0.5, -0.5, 0.5, 1);
var ucvb = vec4(0.5, -0.5, 0.5, 1);
var ucvc = vec4(0.5, 0.5, 0.5, 1);
var ucvd = vec4(-0.5, 0.5, 0.5, 1);

// Vertices for the back
var ucve = vec4(-0.5, -0.5, -0.5, 1);
var ucvf = vec4(0.5, -0.5, -0.5, 1);
var ucvg = vec4(0.5, 0.5, -0.5, 1);
var ucvh = vec4(-0.5, 0.5, -0.5, 1);

// Base vertices for the path
let lineControlPoints = [
    vec4(-0.75, -5, 0.0, 1.0),
    vec4(-8.25, 5, 0.0, 1.0),
    vec4(8.25, 5, 0.0, 1.0),
    vec4(0.75, -5, 0.0, 1.0), 
    vec4(-0.75, 5, 0.0, 1.0),
    vec4(-8.25, -5, 0.0, 1.0),
    vec4(8.25, -5, 0.0, 1.0),
    vec4(0.75, 5, 0.0, 1.0),
];

var lightPosition = vec4(1.0, 1.0, 1.0, 0.0 );
var lightAmbient = vec4(0.4, 0.4, 0.4, 1.0 );
var lightDiffuse = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpecular = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpeed = 0.5; // Used to modify the lightPosition via the arrow keys

var materialAmbient = vec4(1.0, 0.8, 1.0, 1.0 );
var materialDiffuse = vec4(1.0, 0.8, 0.0, 1.0 );
var materialSpecular = vec4(1.0, 1.0, 1.0, 1.0 );
var materialShininess = 20.0;

var modelMatrix, projMatrix, cameraMatrix;
var modelMatrixLoc, projMatrixLoc, cameraLoc;

var eye = vec3(0, 0, -10);
var at = vec3(0.0, 0.0, 0.0);
var up = vec3(0.0, -1.0, 0.0);

let useFlatShading = false;

let animTime = 0; // The timer used to animate the sphere
let animSpeed = 0.001; // The speed the sphere moves on the line
let currentAnimTime = 0;
var animating = false;

function main() {
    const KEY_HANDLERS = {
        KeyA: () => animating ? stopAnimating() : startAnimation(),
        KeyG: () => increasePathSubdivisions(),
        KeyH: () => decreasePathSubdivisions(),
        KeyJ: () => decreaseSphereSubdivisions(),
        KeyK: () => increaseSphereSubdivisions(),
        KeyL: () => toggleShading(),
        KeyM: () => toggleMode(),

        ArrowLeft: () => moveLight("left"),
        ArrowRight: () => moveLight("right"),
        ArrowUp: () => moveLight("up"),
        ArrowDown: () => moveLight("down"),
    };

    const SHIFT_KEY_HANDLERS = {
        ArrowUp: () => moveLight("Zup"),
        ArrowDown: () => moveLight("Zdown"),
    };

    // Retrieve <canvas> element
    canvas = document.getElementById('webgl');

    // Get the rendering context for WebGL
    gl = WebGLUtils.setupWebGL(canvas, undefined);

    // Check that the WebGL context is valid
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return;
    }

    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    mode = gl.LINE_STRIP;

    gl.clearColor(0.0, 0.0, 0.0, 1.0); // Black background
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // Initialize shaders
    program = initShaders(gl, "vshader", "fshader");
    gl.useProgram(program);

    // Set up the viewport
    gl.viewport(0, 0, canvas.width, canvas.height);

    cameraMatrix = lookAt(eye, at, up); // For reference sake: var eye = (vec3(0, 0, -10) vec3(0.0, 0.0, 0.0) vec3(0.0, -1.0, 0.0))
    cameraLoc = gl.getUniformLocation(program, 'cameraMatrix');
    gl.uniformMatrix4fv(cameraLoc, false, flatten(cameraMatrix));

    projectionMatrix = perspective(90, canvas.height / canvas.width, 0.1, 20); 
    projMatrix = gl.getUniformLocation(program, 'projMatrix');
    gl.uniformMatrix4fv(projMatrix, false, flatten(projectionMatrix));

    modelMatrixLoc = gl.getUniformLocation(program, "modelMatrix");
    gl.uniformMatrix4fv(modelMatrixLoc, false, flatten(mat4()));

    // Render the initial scene
    initializePathBuffer();
    initializeSphereBuffers();
    updatePathBuffer();
    updateSphereBuffers();
    renderScene();

    //----------------------------------------------------------------------------
    //
    //  Event Listeners
    //

    // Add event listener to trigger when a key is pressed
    document.addEventListener('keydown', (evt) => {
        evt.preventDefault();
        const transformationHander = KEY_HANDLERS[evt.code];
        const transformationHander2 = SHIFT_KEY_HANDLERS[evt.code];

        if (transformationHander2 && evt.shiftKey) {
            transformationHander2();
            return;
        } else if (transformationHander) {
            transformationHander();
            return;
        }
        
        console.log('Pressed a key without a handler.')
    });
}

//
//
// End of Event Listeners
//----------------------------------------------------------------------------

// Helper function

/**
 * Renders both the sphere and the path into the scene
 * The Sphere is rendered first
 */
function renderScene() {
    console.log("Points Array Length:", pointsArray.length);
    console.log("Normals Array Length:", normalsArray.length);
    renderSphere();
    renderPath();
}

/**
 * Clears the contents of the pointsArray
 */
function resetPointsArray() {
    pointsArray = [];
}

/**
 * Clears the contents of the normalsArray
 */
function resetNormalsArray() {
    normalsArray = [];
}

/**
 * Clears the contents of the flatShadingArray
 */
function resetFlatShadingArray() {
    flatShadingArray = [];
}

/**
 * This function moves the point light in the scene
 * The light can be moved on all 3 axis
 * @param direction A string signaling the direction the light should be moved in 
 */
function moveLight(direction) {
    switch (direction) {
        case "left":
            lightPosition[0] -= lightSpeed;
            updateLightPosition();
            console.log('left');
            break;
        
        case "right":
            lightPosition[0] += lightSpeed;
            updateLightPosition();
            console.log('right');
            break;

        case "up":
            lightPosition[1] += lightSpeed;
            updateLightPosition();
            console.log('up');
            break;

        case "down":
            lightPosition[1] -= lightSpeed;
            updateLightPosition();
            console.log('down');
            break;

        case "Zup":
            lightPosition[2] += lightSpeed;
            updateLightPosition();
            console.log('Zup');
            break;

        case "Zdown":
            lightPosition[2] -= lightSpeed
            updateLightPosition();
            console.log('Zdown');
            break;
    
        default:
            break;
    }
}

/**
 * This function passes the changed light position (vec4) to the vertex shader
 */
function updateLightPosition() {
    console.log('Light position: ', lightPosition);
    gl.uniform4fv(gl.getUniformLocation(program, "lightPosition"), flatten(lightPosition));
    renderScene(); // Redraw the scene with the new light position
}

/**
 * A function to stop the sphere's motion along the path
 * The sphere's position along the path is stored so that the animation can be unpaused correctly
 */
function stopAnimating() {
    currentAnimTime = animTime;
    animating = false;
}