/* EXTRA CREDIT 
 -> I added a color picker feature that determines the color of the user created lines (right click generated)
 -> I added an export button to export the current drawing as a svg file, which can be reloaded by the editor
 (Functionality can be found on this file in the drawLines function in transformImage.js and in the 
  exportAsSVG function in parseSVG.js)
*/

// The data of the drawing currently being rendered by the program and the frame buffer
var currentDrawingData = null;

// The transformations currently applied to the currently active drawing (if any)
var currentTranslation = { x: 0, y: 0, };
var currentRotation = 0;
var currentScale = 1;

// Variable to store the mouse cursor position when dragging
var currentMousePosition = { x: 0, y: 0, };

// Variable that references the last drawn point on the canvas (by a user, NOT an svg file)
// A reference to the first point created when right-clicking; reset when a line is created
var createdPoint = null; 

function main() {
    const KEY_HANDLERS = {
        KeyR: () => resetDrawing(gl, program),
    };

    // Retrieve <canvas> element
    let canvas = document.getElementById('webgl');

    // Get the rendering context for WebGL
    let gl = WebGLUtils.setupWebGL(canvas, undefined);

    // Check that the WebGL context is valid
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return;
    }

    // Initialize shaders
    let program = initShaders(gl, "vshader", "fshader");
    gl.useProgram(program);

    // Set up the viewport
    gl.viewport(0, 0, canvas.width, canvas.height);

    // Add project matrix to the html
    let projectionMatrix = ortho(-1, 1, -1, 1, -1, 1); // Default bounds 
    let projMatrix = gl.getUniformLocation(program, 'projMatrix');
    gl.uniformMatrix4fv(projMatrix, false, flatten(projectionMatrix));

    let modelMatrix = gl.getUniformLocation(program, "modelMatrix");
    gl.uniformMatrix4fv(modelMatrix, false, flatten(mat4()));

    //----------------------------------------------------------------------------
    //
    //  Event Listeners
    //
    
    
    // Add event listener to trigger when uploaded svg file changes
    let fileInputElement = document.getElementById("files");
    fileInputElement.addEventListener("change", function (evt) { 
        readUploadedFile(evt, gl, program);
    });

    // Add event listener to trigger when pressing the export button
    document.getElementById("export-svg").addEventListener("click", function (evt) {
        evt.preventDefault(); // Prevents form reset if inside a <form>
        exportAsSVG();
    });

    // Add event listener to trigger when a key is pressed
    document.addEventListener('keydown', (evt) => {
        evt.preventDefault(); // To trigger console warnings if the program runs wrong
    
        const transformationHandler = KEY_HANDLERS[evt.code];
        
        if (transformationHandler) { // Check if a valid key-function pair (so to speak) exists for the key pressed
          transformationHandler(); // Call function associated with pressing key
          return;
        }
        
        console.log('Pressed a key without a handler.')
    });

    let intervalId = null; // id of the setInterval function called when mouse button is held
    let isMouseDown = false; 

    // Event listener to trigger when mouse is held down (left-click)
    document.addEventListener('mousedown', (evt) => {
        evt.preventDefault();
    
        isMouseDown = true;
        const canvasCoords = convertToCanvasCoordinates(evt, canvas);
        initialPosition = { x: canvasCoords.x, y: canvasCoords.y };

        if (!intervalId) {
            if (evt.button === 0) {
                intervalId = setInterval(() => {
                    const xChange = currentMousePosition.x - initialPosition.x;
                    const yChange = currentMousePosition.y - initialPosition.y;
    
                    currentTranslation.x += xChange;
                    currentTranslation.y += yChange;
    
                    updateDrawingPosition(gl, program);
    
                    initialPosition = { 
                        x: currentMousePosition.x, 
                        y: currentMousePosition.y 
                    };
                }, 100); // Call function every 100ms
            } else if (evt.button === 2) {
                let lineColor = document.getElementById("color-hex").value;
                console.log("Right mouse button clicked");
                drawNewLine(gl, program, initialPosition, lineColor);
            }
        }
    });
    
    // Event listener to trigger when the mouse is released
    document.addEventListener('mouseup', () => {
        isMouseDown = false;
    
        // Clear the interval and reset the intervalId since function should stop
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
    });

    // Event listener to trigger when the mouse cursor moves
    // I'm using it to simply get the cursor's most accurate coordinates
    document.addEventListener('mousemove', (evt) => {
        if (isMouseDown) {
            currentMousePosition = convertToCanvasCoordinates(evt, canvas);
        }
    });
    
    // Event listener for when the mouse leaves the window to ensure proper behavior overall
    // and no funkiness
    document.addEventListener('mouseleave', () => {
        isMouseDown = false;
    
        // Clear the interval and reset the intervalId to stop the updateDrawingPosition function
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
    });

    // Event listener to trigger when scrolling using the mousewheel/trackpad
    // Triggers whether or not shift key is pressed -> individual handling for that is
    // taken care of in the eventListener
    document.addEventListener('wheel', (evt) => {
        if (evt.shiftKey) { // If the shift key is being pressed
            if (evt.deltaY > 0) { // Check if user is scrolling up
                console.log('Scrolling up with shift');
                increaseDrawingScale(gl, program);
            } else if (evt.deltaY < 0) { // Check if user is scrolling down
                console.log('Scrolling down with shift');
                decreaseDrawingScale(gl, program);
            }
        } else {
            if (evt.deltaY > 0) {
                console.log('Scrolling up');
                rotateDrawingClockwise(gl, program);
            } else if (evt.deltaY < 0) {
                console.log('Scrolling down');
                rotateDrawingCounterclockwise(gl, program);
            }
        }
    });
}

//
//
// End of Event Listeners
//----------------------------------------------------------------------------

// Helper function

/**
 * Converts the coordinates of a mouse cursor's point in viewpoint coordinates to coordinates in the canvas bounds
 * @param evt The mouse down event that brings with it the cursor's (relative) position via clientX/Y
 * @param canvas  The canvas whose bounds will assist in this calculation
 * @returns 
 */
function convertToCanvasCoordinates(evt, canvas) {
    const rect = canvas.getBoundingClientRect(); // Get canvas bounds relative to viewport
    
    // Normalize the coordinates
    const x = ((evt.clientX - rect.left) / canvas.width) * 2 - 1; 
    const y = -(((evt.clientY - rect.top) / canvas.height) * 2 - 1); 
    return { x, y };
}