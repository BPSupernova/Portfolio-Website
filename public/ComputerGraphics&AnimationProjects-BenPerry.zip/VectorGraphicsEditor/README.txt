Probably my favorite of my Computer Graphics / Computer Animations projects. The run this project simply open index.html in a local host. 

In the editor the user can load svg files (some provided via the files folder in the same folder of this README) which they can then edit. 

To create new lines simply right click once to create a point, then right click again to create a line. There is a color picker at the bottom of the page where you can choose a color to use.

The user can also export their current drawing into their own svg by clicking the "Export Current Drawing" button below the color picker.

In the editor space the user can click and drag to move the linework, scroll up and down with the mouse to rotate the image, hold shift while scrolling to scale the image, and press R to reset the view to its default state.

Enjoy!